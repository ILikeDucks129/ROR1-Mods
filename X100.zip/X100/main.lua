
------ main.lua
---- This file is automatically loaded by RoRML

-- Load the other Lua scripts

require("x100")