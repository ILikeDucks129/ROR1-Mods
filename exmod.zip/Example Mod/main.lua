
------ main.lua
---- This file is automatically loaded by RoRML

-- Load the other Lua scripts

require("juice")
require("voltberry")
require("scarf")
require("jam")
require("example artifact")
